import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'api.dart';
import 'main.dart';
import 'mcp.dart';
import 'oauth.dart';
import 'store.dart';
import 'ui.dart';

// ---------------------------------------------------------------- API key
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final b = TextEditingController(text: Api.baseUrl);
  final k = TextEditingController(text: Api.apiKey);
  final up = TextEditingController(text: Api.usagePath);
  String connMsg = 'Not checked yet', chatMsg = 'Not tested yet';
  bool? connOk, chatOk;
  bool busy = false, show = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    b.addListener(_auto);
    k.addListener(_auto);
    if (Api.ready) _check();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _auto() {
    _t?.cancel();
    if (b.text.trim().isEmpty || k.text.trim().length < 8) return;
    _t = Timer(const Duration(milliseconds: 900), _check);
  }

  Future<void> _check() async {
    if (!mounted) return;
    setState(() {
      busy = true;
      connOk = null;
      chatOk = null;
      connMsg = 'Checking…';
      chatMsg = 'Not tested yet';
    });
    try {
      final m = await Api.check(b.text, k.text);
      if (mounted) {
        setState(() {
          connOk = true;
          connMsg = '${m.length} models found (${Api.proto} format)';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          connOk = false;
          connMsg = Api.explain(e);
        });
      }
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _full() async {
    await _check();
    if (connOk != true || !mounted) return;
    setState(() {
      busy = true;
      chatMsg = 'Sending a short test message…';
    });
    try {
      final m = await Api.testChat();
      if (mounted) {
        setState(() {
          chatOk = true;
          chatMsg = 'Chat works (tested with $m)';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          chatOk = false;
          chatMsg = Api.friendly(e.toString());
        });
      }
    }
    if (mounted) setState(() => busy = false);
  }

  Widget st(bool? ok) => ok == null
      ? (busy
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: accent))
          : Icon(Icons.remove, color: mut2))
      : Icon(ok ? Icons.check_circle : Icons.error,
          color: ok ? Colors.green.shade700 : Colors.red.shade700);

  @override
  Widget build(BuildContext context) => uiPage('API key', [
        Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Connect Lumora to your key system. It detects the format and lists every model on the key.',
                style: TextStyle(color: mut, height: 1.4))),
        uiField(b, 'Base URL',
            hint: 'https://api.example.com', type: TextInputType.url),
        uiField(k, 'API key',
            obscure: !show,
            suffix: IconButton(
                icon: Icon(show ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => show = !show))),
        uiField(up, 'Usage / balance address (optional)',
            hint: '/v1/usage  or  https://…', type: TextInputType.url),
        Padding(
            padding: EdgeInsets.only(left: 4, bottom: 18),
            child: Text(
                'If your key system has an address that shows tokens, quota or balance, paste it here. The dashboard will show everything it returns.',
                style: TextStyle(fontSize: 12.5, color: mut2, height: 1.4))),
        uiSection('Status', [
          uiRow('Connection',
              sub: connMsg, icon: Icons.link, trailing: st(connOk)),
          uiRow('Chat test',
              sub: chatMsg,
              icon: Icons.chat_bubble_outline,
              trailing: st(chatOk)),
        ]),
        uiButton(busy ? 'Working…' : 'Test connection and chat',
            busy ? null : _full),
        const SizedBox(height: 10),
        uiButton('Save', () async {
          await Api.save(b.text, k.text);
          await Api.setUsagePath(up.text);
          if (context.mounted) Navigator.pop(context, true);
        }, primary: false),
      ]);
}

// -------------------------------------------------------------- Dashboard
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map<String, dynamic>? q;
  int? nModels;
  String err = '';
  bool loading = true;
  final lim = TextEditingController(
      text: Store.limit == 0 ? '' : Store.limit.toString());
  final pin = TextEditingController(
      text: Store.priceIn == 0 ? '' : Store.priceIn.toString());
  final pout = TextEditingController(
      text: Store.priceOut == 0 ? '' : Store.priceOut.toString());

  String get _mk => DateTime.now().toIso8601String().substring(0, 7);
  String dk(DateTime d) => d.toIso8601String().substring(0, 10);
  int dv(DateTime d, String f) => (Store.daily[dk(d)]?[f] ?? 0) as int;
  int monthSum(String f) {
    var t = 0;
    Store.daily.forEach((k, v) {
      if (k.startsWith(_mk)) t += (v[f] ?? 0) as int;
    });
    return t;
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    Store.save();
    super.dispose();
  }

  Future<void> load() async {
    setState(() => loading = true);
    final qf = Api.quotaInfo();
    try {
      nModels = (await Api.models()).length;
      err = '';
    } catch (e) {
      err = Api.explain(e);
      nModels = null;
    }
    try {
      q = await qf;
    } catch (_) {
      q = {'rows': <List<String>>[], 'raw': null};
    }
    if (mounted) setState(() => loading = false);
  }

  String mask(String k) => k.length <= 10
      ? '••••'
      : '${k.substring(0, 6)}••••${k.substring(k.length - 4)}';
  String fmt(int n) => n >= 1000000
      ? '${(n / 1e6).toStringAsFixed(2)}M'
      : n >= 1000
          ? '${(n / 1e3).toStringAsFixed(1)}K'
          : '$n';
  String money(double v) =>
      '\$${v < 1 ? v.toStringAsFixed(4) : v.toStringAsFixed(2)}';

  Widget card(Widget child, {Color? color}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
          color: color ?? surf,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color == null ? line : Colors.transparent)),
      child: child);

  Widget head(String t, {Widget? trailing}) => Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(children: [
        Expanded(
            child: Text(t,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
        if (trailing != null) trailing,
      ]));

  Widget kv(String k, String v, {Color? c}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Text(k, style: TextStyle(color: mut))),
        const SizedBox(width: 12),
        Flexible(
            flex: 2,
            child: Text(v,
                textAlign: TextAlign.right,
                style: TextStyle(fontWeight: FontWeight.w600, color: c))),
      ]));

  Widget kpi(String label, String value, IconData icon) => Expanded(
      child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: surf,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, size: 18, color: accent)),
            const SizedBox(height: 12),
            Text(value,
                style: TextStyle(
                    fontSize: 24, fontWeight: FontWeight.w700, color: ink)),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(fontSize: 12.5, color: mut)),
          ])));

  Widget chart() {
    final now = DateTime.now();
    final days = [for (var i = 13; i >= 0; i--) now.subtract(Duration(days: i))];
    final vals = [for (final d in days) dv(d, 'i') + dv(d, 'o')];
    final mx = vals.fold<int>(1, (a, v) => v > a ? v : a);
    return SizedBox(
        height: 150,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          for (var i = 0; i < days.length; i++)
            Expanded(
                child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Container(
                          height: vals[i] == 0 ? 2.0 : 6 + 100.0 * vals[i] / mx,
                          decoration: BoxDecoration(
                              color: vals[i] == 0
                                  ? line
                                  : (i == days.length - 1
                                      ? accent
                                      : accent.withValues(alpha: 0.4)),
                              borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(5)))),
                      const SizedBox(height: 6),
                      Text('${days[i].day}',
                          style: TextStyle(fontSize: 10, color: mut2)),
                    ]))),
        ]));
  }

  Widget modelBars(int total) {
    final es = Store.usage.entries.toList()
      ..sort((a, b) => ((b.value['i'] as int) + (b.value['o'] as int))
          .compareTo((a.value['i'] as int) + (a.value['o'] as int)));
    return Column(children: [
      for (final e in es)
        Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                    child: Text(e.key,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 14))),
                Text(
                    '${fmt((e.value['i'] as int) + (e.value['o'] as int))}  ·  ${total == 0 ? 0 : (((e.value['i'] as int) + (e.value['o'] as int)) * 100 / total).round()}%',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              ]),
              const SizedBox(height: 6),
              ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                      minHeight: 6,
                      value: total == 0
                          ? 0.0
                          : ((e.value['i'] as int) + (e.value['o'] as int)) / total,
                      color: accent,
                      backgroundColor: soft)),
              const SizedBox(height: 4),
              Text('${e.value['n']} requests',
                  style: TextStyle(fontSize: 12, color: mut2)),
            ])),
    ]);
  }

  Widget rateCard() {
    final r = Api.rate;
    int? gi(String k) => int.tryParse(r[k] ?? '');
    final limit = gi('x-ratelimit-limit') ?? gi('x-ratelimit-limit-requests');
    final rem = gi('x-ratelimit-remaining') ?? gi('x-ratelimit-remaining-requests');
    final reset = gi('x-ratelimit-reset') ?? gi('x-ratelimit-reset-requests');
    String? resetTxt;
    if (reset != null && reset > 1000000000) {
      final d = DateTime.fromMillisecondsSinceEpoch(reset * 1000);
      final mins = d.difference(DateTime.now()).inMinutes;
      resetTxt =
          'Resets ${mins > 0 ? 'in $mins min' : 'soon'} (${d.toString().substring(11, 16)})';
    }
    final shown = {'x-ratelimit-limit', 'x-ratelimit-remaining', 'x-ratelimit-reset'};
    return card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      head('Request rate limit'),
      if (limit != null && rem != null) ...[
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('$rem',
              style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w700)),
          const SizedBox(width: 6),
          Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text('of $limit requests left',
                  style: TextStyle(color: mut))),
        ]),
        const SizedBox(height: 10),
        ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
                minHeight: 8,
                value: limit == 0 ? 0.0 : rem / limit,
                color: rem / (limit == 0 ? 1 : limit) < 0.15 ? Colors.red : accent,
                backgroundColor: soft)),
        if (resetTxt != null)
          Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(resetTxt,
                  style: TextStyle(fontSize: 12.5, color: mut))),
      ],
      for (final e in r.entries.where((e) => !shown.contains(e.key)))
        kv(e.key, e.value),
    ]));
  }

  @override
  Widget build(BuildContext context) {
    int ti = 0, to = 0, reqs = 0;
    Store.usage.forEach((_, u) {
      ti += u['i'] as int;
      to += u['o'] as int;
      reqs += u['n'] as int;
    });
    final used = Store.monthly[_mk] ?? 0;
    final mi = monthSum('i'), mo = monthSum('o'), mr = monthSum('n');
    final hasPrice = Store.priceIn > 0 || Store.priceOut > 0;
    final costMonth = mi / 1e6 * Store.priceIn + mo / 1e6 * Store.priceOut;
    final costAll = ti / 1e6 * Store.priceIn + to / 1e6 * Store.priceOut;
    final rows = (q?['rows'] as List?)?.cast<List<String>>() ?? [];
    final raw = q?['raw'] as String?;
    final ok = !loading && err.isEmpty && Api.ready;
    return uiPage('Dashboard', [
      card(
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('This month',
                  style: TextStyle(color: Colors.white70, fontSize: 14)),
              const Spacer(),
              Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.circle,
                        size: 9,
                        color: loading
                            ? Colors.white54
                            : (ok ? Colors.greenAccent : Colors.redAccent)),
                    const SizedBox(width: 6),
                    Text(loading ? 'Checking' : (ok ? 'Connected' : 'Offline'),
                        style: const TextStyle(color: Colors.white, fontSize: 12.5)),
                  ])),
            ]),
            const SizedBox(height: 8),
            Text(fmt(used),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 46,
                    fontFamily: 'serif',
                    fontWeight: FontWeight.w600)),
            const Text('tokens', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            if (Store.limit > 0) ...[
              ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                      minHeight: 8,
                      value: used >= Store.limit ? 1.0 : used / Store.limit,
                      color: used >= Store.limit ? Colors.redAccent : accent,
                      backgroundColor: Colors.white24)),
              const SizedBox(height: 6),
              Text('${(used * 100 / Store.limit).round()}% of ${fmt(Store.limit)} limit',
                  style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
            ] else
              const Text('No monthly limit set',
                  style: TextStyle(color: Colors.white54, fontSize: 12.5)),
          ]),
          color: heroBg),
      Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(children: [
            kpi('Requests this month', '$mr', Icons.bolt),
            const SizedBox(width: 12),
            kpi('All-time tokens', fmt(ti + to), Icons.all_inclusive),
          ])),
      Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Row(children: [
            kpi('Input tokens (month)', fmt(mi), Icons.south_west),
            const SizedBox(width: 12),
            kpi('Output tokens (month)', fmt(mo), Icons.north_east),
          ])),
      if (hasPrice)
        Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Row(children: [
              kpi('Estimated cost (month)', money(costMonth), Icons.payments_outlined),
              const SizedBox(width: 12),
              kpi('Estimated cost (all time)', money(costAll), Icons.savings_outlined),
            ])),
      card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        head('Last 14 days',
            trailing: Text('$reqs requests total',
                style: TextStyle(fontSize: 12.5, color: mut2))),
        chart(),
      ])),
      if (Store.usage.isNotEmpty)
        card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          head('Usage by model'),
          modelBars(ti + to),
        ])),
      card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        head('Key balance and limits'),
        if (rows.isEmpty) ...[
          Text(
              loading
                  ? 'Checking…'
                  : 'Lumora could not find a usage or balance address on this key system.',
              style: TextStyle(color: mut, height: 1.4)),
          if (!loading) ...[
            const SizedBox(height: 12),
            uiButton('Add usage address', () async {
              await Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()));
              load();
            }, primary: false),
          ],
        ] else
          for (final r in rows) kv(r[0], r[1]),
      ])),
      if (Api.rate.isNotEmpty) rateCard(),
      card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        head('Connection',
            trailing: IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.refresh),
                onPressed: loading ? null : load)),
        if (err.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(err,
                  style: TextStyle(color: Colors.red.shade700, height: 1.4))),
        kv('Base URL', Api.baseUrl.isEmpty ? '—' : Api.baseUrl),
        kv('API key', Api.apiKey.isEmpty ? '—' : mask(Api.apiKey)),
        kv('Format', Api.proto),
        kv('Models available', nModels?.toString() ?? '—'),
        kv('Chats saved', '${Store.chats.length}'),
      ])),
      card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        head('Limit and cost estimate'),
        uiField(lim, 'Monthly token limit (0 = none)',
            type: TextInputType.number, onChanged: (v) {
          Store.limit = int.tryParse(v) ?? 0;
          setState(() {});
        }),
        uiField(pin, 'Price per 1M input tokens (USD)',
            type: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (v) {
          Store.priceIn = double.tryParse(v) ?? 0;
          setState(() {});
        }),
        uiField(pout, 'Price per 1M output tokens (USD)',
            type: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (v) {
          Store.priceOut = double.tryParse(v) ?? 0;
          setState(() {});
        }),
      ])),
      if (raw != null)
        Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
                title: const Text('Raw server response'),
                children: [
                  Padding(padding: const EdgeInsets.all(12), child: SelectableText(raw))
                ])),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(
            child: uiButton('Backup', () async {
          await Clipboard.setData(ClipboardData(text: Store.exportAll()));
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Backup copied. Paste it in a safe place.')));
          }
        }, primary: false)),
        const SizedBox(width: 12),
        Expanded(
            child: uiButton('Restore', () async {
          final d = await Clipboard.getData('text/plain');
          try {
            Store.importAll(d?.text ?? '');
            await Store.save();
            if (mounted) setState(() {});
          } catch (_) {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Clipboard has no valid backup.')));
            }
          }
        }, primary: false)),
      ]),
    ]);
  }
}

class PersonaPage extends StatefulWidget {
  const PersonaPage({super.key});
  @override
  State<PersonaPage> createState() => _PersonaPageState();
}

class _PersonaPageState extends State<PersonaPage> {
  final p = TextEditingController(text: Store.persona);
  final n = TextEditingController(text: Store.notes);
  @override
  Widget build(BuildContext context) => uiPage('Persona & memory', [
        Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Both are sent with every message, so Lumora always follows your style and remembers what matters to you.',
                style: TextStyle(color: mut, height: 1.4))),
        uiField(p, 'Persona',
            lines: 4,
            hint: 'e.g. Answer briefly, in Bengali, like a friendly teacher'),
        uiField(n, 'Memory',
            lines: 7, hint: 'Things Lumora should always remember about you'),
        uiButton('Save', () async {
          Store.persona = p.text.trim();
          Store.notes = n.text.trim();
          await Store.save();
          if (context.mounted) Navigator.pop(context);
        }),
      ]);
}

// --------------------------------------------------------------- Connectors
class ConnectorsPage extends StatefulWidget {
  const ConnectorsPage({super.key});
  @override
  State<ConnectorsPage> createState() => _ConnectorsPageState();
}

class _ConnectorsPageState extends State<ConnectorsPage> {
  void snack(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> add() async {
    final n = TextEditingController(),
        u = TextEditingController(),
        t = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: bg,
              title: const Text('Add connector'),
              content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  uiField(n, 'Name'),
                  uiField(u, 'Server URL (https)',
                      type: TextInputType.url, hint: 'https://example.com/mcp'),
                  uiField(t, 'Token (leave empty for OAuth)', obscure: true),
                ]),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: accent),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Add')),
              ],
            ));
    if (ok == true && u.text.trim().isNotEmpty) {
      Store.mcps.add({
        'name': n.text.trim().isEmpty ? u.text.trim() : n.text.trim(),
        'url': u.text.trim(),
        'token': t.text.trim(),
        'on': true
      });
      await Store.save();
      setState(() {});
    }
  }

  Future<void> signIn(Map s) async {
    snack('Opening login...');
    try {
      s['oauth'] = await OAuth.login(s['url']);
      await Store.save();
      snack('Signed in.');
      setState(() {});
    } catch (e) {
      snack('Sign-in failed: ${Api.explain(e)}');
    }
  }

  Future<void> test(Map s) async {
    snack('Connecting...');
    try {
      final c = McpClient(s['url'], await OAuth.token(s));
      await c.init();
      final t = await c.tools();
      snack('Connected. ${t.length} tools: ${t.take(5).map((e) => e['name']).join(', ')}');
    } catch (e) {
      snack('Failed: ${Api.explain(e)}');
    }
  }

  void actions(Map s) => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (_) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            uiRow('Test connection', icon: Icons.bolt, onTap: () {
              Navigator.pop(context);
              test(s);
            }),
            uiRow('Sign in with OAuth', icon: Icons.login, onTap: () {
              Navigator.pop(context);
              signIn(s);
            }),
            uiRow('Remove',
                icon: Icons.delete_outline,
                color: Colors.red.shade700, onTap: () async {
              Navigator.pop(context);
              Store.mcps.remove(s);
              await Store.save();
              setState(() {});
            }),
            const SizedBox(height: 8),
          ])));

  @override
  Widget build(BuildContext context) => uiPage('Connectors (MCP)', [
        Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Connect remote MCP servers so Lumora can use their tools in chat. Tap a connector for more options.',
                style: TextStyle(color: mut, height: 1.4))),
        if (Store.mcps.isEmpty)
          uiSection('', [
            uiRow('No connectors yet',
                sub: 'Tap + to add a remote MCP server.',
                icon: Icons.hub_outlined)
          ])
        else
          uiSection('Servers', [
            for (final s in Store.mcps)
              uiRow(s['name'],
                  sub: '${s['url']}${s['oauth'] != null ? '  ·  signed in' : ''}',
                  icon: Icons.hub_outlined,
                  onTap: () => actions(s),
                  trailing: Switch(
                      value: s['on'] == true,
                      activeThumbColor: accent,
                      onChanged: (v) async {
                        s['on'] = v;
                        await Store.save();
                        setState(() {});
                      })),
          ]),
      ],
          fab: FloatingActionButton(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              onPressed: add,
              child: const Icon(Icons.add)));
}

// ----------------------------------------------------------- Prompt library
class PromptsPage extends StatefulWidget {
  const PromptsPage({super.key});
  @override
  State<PromptsPage> createState() => _PromptsPageState();
}

class _PromptsPageState extends State<PromptsPage> {
  Future<void> add() async {
    final c = TextEditingController();
    final t = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: bg,
              title: const Text('New prompt'),
              content: SingleChildScrollView(child: uiField(c, 'Prompt', lines: 4)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: accent),
                    onPressed: () => Navigator.pop(context, c.text),
                    child: const Text('Save')),
              ],
            ));
    if (t != null && t.trim().isNotEmpty) {
      Store.prompts.add(t.trim());
      await Store.save();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => uiPage('Prompt library', [
        if (Store.prompts.isEmpty)
          uiSection('', [
            uiRow('No saved prompts yet',
                sub: 'Tap + to save a prompt you use often.',
                icon: Icons.bookmark_border)
          ])
        else
          uiSection('Tap a prompt to use it', [
            for (var i = 0; i < Store.prompts.length; i++)
              uiRow(Store.prompts[i],
                  icon: Icons.bookmark_border,
                  onTap: () => Navigator.pop(context, Store.prompts[i]),
                  trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        Store.prompts.removeAt(i);
                        await Store.save();
                        setState(() {});
                      })),
          ]),
      ],
          fab: FloatingActionButton(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              onPressed: add,
              child: const Icon(Icons.add)));
}

// ------------------------------------------------------------------ Compare
class ComparePage extends StatefulWidget {
  final List<String> models;
  const ComparePage(this.models, {super.key});
  @override
  State<ComparePage> createState() => _ComparePageState();
}

class _ComparePageState extends State<ComparePage> {
  late String a = widget.models.first;
  late String b =
      widget.models.length > 1 ? widget.models[1] : widget.models.first;
  final q = TextEditingController();
  String ra = '', rb = '';
  bool busy = false;

  Future<void> run(bool first) async {
    final m = first ? a : b;
    try {
      await for (final c
          in Api.chat(m, [{'role': 'user', 'content': q.text}], null)) {
        if (!mounted) return;
        setState(() => first ? ra += c : rb += c);
      }
    } catch (e) {
      if (mounted) {
        setState(() => first
            ? ra = Api.friendly(e.toString(), m)
            : rb = Api.friendly(e.toString(), m));
      }
    }
  }

  Future<void> go() async {
    if (q.text.trim().isEmpty || busy) return;
    setState(() {
      busy = true;
      ra = '';
      rb = '';
    });
    await Future.wait([run(true), run(false)]);
    if (mounted) setState(() => busy = false);
  }

  Widget dd(String v, void Function(String) on) => ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 210),
      child: DropdownButton<String>(
          isExpanded: true,
          underline: const SizedBox(),
          value: v,
          items: [
            for (final m in widget.models)
              DropdownMenuItem(
                  value: m, child: Text(m, overflow: TextOverflow.ellipsis))
          ],
          onChanged: (x) => setState(() => on(x!))));

  Widget card(String label, String t) => uiSection(label, [
        Padding(
            padding: const EdgeInsets.all(14),
            child: SelectableText(t.isEmpty ? '…' : t,
                style: TextStyle(fontSize: 15, height: 1.45, color: ink)))
      ]);

  @override
  Widget build(BuildContext context) => uiPage('Compare models', [
        uiSection('Models', [
          uiRow('Model A', trailing: dd(a, (x) => a = x)),
          uiRow('Model B', trailing: dd(b, (x) => b = x)),
        ]),
        uiField(q, 'Question',
            lines: 2, hint: 'Ask both models the same question'),
        uiButton(busy ? 'Running…' : 'Run both', busy ? null : go),
        const SizedBox(height: 22),
        card('Model A', ra),
        card('Model B', rb),
      ]);
}

// ------------------------------------------------------------------ Preview
class PreviewPage extends StatefulWidget {
  final String html;
  const PreviewPage(this.html, {super.key});
  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  late final WebViewController c = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..loadHtmlString(widget.html);
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Preview')),
      body: WebViewWidget(controller: c));
}

// -------------------------------------------------------------------- Chats
class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  String q = '';

  String bucket(Chat c) {
    if (c.pinned) return 'Pinned';
    final d = DateTime.fromMillisecondsSinceEpoch(c.ts);
    final n = DateTime.now();
    final days = DateTime(n.year, n.month, n.day)
        .difference(DateTime(d.year, d.month, d.day))
        .inDays;
    if (days <= 0) return 'Today';
    if (days == 1) return 'Yesterday';
    if (days <= 7) return 'Previous 7 days';
    return 'Older';
  }

  @override
  Widget build(BuildContext context) {
    final ql = q.toLowerCase();
    final list = Store.sorted()
        .where((c) =>
            ql.isEmpty ||
            c.title.toLowerCase().contains(ql) ||
            c.msgs.any((m) => m.text.toLowerCase().contains(ql)))
        .toList();
    String proj(Chat c) {
      for (final p in Store.projects) {
        if (p.id == c.pid) return '  ·  ${p.name}';
      }
      return '';
    }

    return uiPage('Chats', [
      Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: TextField(
              onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(
                  hintText: 'Search your chats',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: soft,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none)))),
      if (list.isEmpty)
        uiSection('', [
          uiRow(q.isEmpty ? 'No chats yet' : 'No chats match',
              icon: Icons.chat_bubble_outline)
        ]),
      for (final label in ['Pinned', 'Today', 'Yesterday', 'Previous 7 days', 'Older'])
        if (list.any((c) => bucket(c) == label))
          uiSection(label, [
            for (final c in list.where((c) => bucket(c) == label))
              uiRow(c.title,
                  sub: '${c.mode}${proj(c)}  ·  ${c.msgs.length ~/ 2} messages',
                  icon: c.pinned ? Icons.push_pin : modeIcon(c.mode),
                  onTap: () => Navigator.pop(context, c),
                  trailing: IconButton(
                      icon: const Icon(Icons.more_horiz),
                      onPressed: () =>
                          chatMenu(context, c, () => setState(() {})))),
          ]),
    ]);
  }
}

Future<void> renameChat(BuildContext context, Chat c) async {
  final t = TextEditingController(text: c.title);
  final r = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
            backgroundColor: bg,
            title: const Text('Rename chat'),
            content: SingleChildScrollView(child: uiField(t, 'Title')),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel')),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: accent),
                  onPressed: () => Navigator.pop(context, t.text),
                  child: const Text('Save')),
            ],
          ));
  if (r != null && r.trim().isNotEmpty) {
    c.title = r.trim();
    await Store.save();
  }
}

Future<bool> deleteChat(BuildContext context, Chat c) async {
  final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
            backgroundColor: bg,
            title: const Text('Delete this chat?'),
            content: const Text('This cannot be undone.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel')),
              TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: Text('Delete', style: TextStyle(color: Colors.red.shade700))),
            ],
          ));
  if (ok == true) {
    Store.chats.remove(c);
    await Store.save();
    return true;
  }
  return false;
}

Future<void> pickProject(BuildContext context, Chat c) async {
  await showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (sheet) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            uiRow('No project', icon: Icons.block, onTap: () async {
              c.pid = null;
              await Store.save();
              if (sheet.mounted) Navigator.pop(sheet);
            }),
            for (final p in Store.projects)
              uiRow(p.name,
                  icon: Icons.folder_open,
                  trailing: c.pid == p.id
                      ? const Icon(Icons.check, color: accent)
                      : null, onTap: () async {
                c.pid = p.id;
                await Store.save();
                if (sheet.mounted) Navigator.pop(sheet);
              }),
            const SizedBox(height: 8),
          ])));
}

/// Pin / rename / add to project / delete, as a bottom sheet.
Future<void> chatMenu(BuildContext context, Chat c, VoidCallback changed) async {
  await showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (sheet) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(c.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 15, color: mut)))),
            uiRow(c.pinned ? 'Unpin' : 'Pin',
                icon: c.pinned ? Icons.push_pin : Icons.push_pin_outlined,
                onTap: () async {
              c.pinned = !c.pinned;
              await Store.save();
              if (sheet.mounted) Navigator.pop(sheet);
              changed();
            }),
            uiRow('Rename', icon: Icons.edit_outlined, onTap: () async {
              Navigator.pop(sheet);
              await renameChat(context, c);
              changed();
            }),
            uiRow('Add to project', icon: Icons.folder_open, onTap: () async {
              Navigator.pop(sheet);
              await pickProject(context, c);
              changed();
            }),
            uiRow('Delete',
                icon: Icons.delete_outline,
                color: Colors.red.shade700, onTap: () async {
              Navigator.pop(sheet);
              await deleteChat(context, c);
              changed();
            }),
            const SizedBox(height: 8),
          ])));
}

// ---------------------------------------------------------------- Artifacts
class ArtifactsPage extends StatelessWidget {
  const ArtifactsPage({super.key});

  List<Map<String, String>> items() {
    final out = <Map<String, String>>[];
    for (final c in Store.chats) {
      for (final m in c.msgs.where((m) => !m.user && !m.err)) {
        final parts = m.text.split('```');
        for (var i = 1; i < parts.length; i += 2) {
          final raw = parts[i];
          final nl = raw.indexOf('\n');
          final lang = nl > 0 ? raw.substring(0, nl).trim().toLowerCase() : '';
          final src = nl >= 0 ? raw.substring(nl + 1) : raw;
          if (src.trim().length < 20) continue;
          out.add({'lang': lang, 'src': src, 'chat': c.title});
        }
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final list = items();
    return uiPage('Artifacts', [
      Padding(
          padding: EdgeInsets.only(bottom: 18, left: 4),
          child: Text('Code and web pages Lumora has written in your chats.',
              style: TextStyle(color: mut, height: 1.4))),
      if (list.isEmpty)
        uiSection('', [
          uiRow('Nothing here yet',
              sub: 'Ask Lumora to write some code or an HTML page.',
              icon: Icons.auto_awesome_motion_outlined)
        ])
      else
        uiSection('', [
          for (final it in list)
            uiRow('${it['lang']!.isEmpty ? 'code' : it['lang']} · ${it['chat']}',
                sub: it['src']!.trim().split('\n').first,
                icon: it['lang'] == 'html' ? Icons.web : Icons.code,
                onTap: () {
                  if (it['lang'] == 'html') {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PreviewPage(it['src']!)));
                  } else {
                    showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: bg,
                        builder: (_) => SafeArea(
                            child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(mainAxisSize: MainAxisSize.min, children: [
                                  Flexible(
                                      child: SingleChildScrollView(
                                          child: SelectableText(it['src']!,
                                              style: const TextStyle(
                                                  fontFamily: 'monospace',
                                                  fontSize: 13)))),
                                  const SizedBox(height: 12),
                                  uiButton('Copy', () {
                                    Clipboard.setData(
                                        ClipboardData(text: it['src']!));
                                    Navigator.pop(context);
                                  }),
                                ]))));
                  }
                }),
        ]),
    ]);
  }
}
