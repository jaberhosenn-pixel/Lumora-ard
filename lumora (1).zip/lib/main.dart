import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'chat_page.dart';
import 'store.dart';

const accent = Color(0xFFC96442);
Color bg = const Color(0xFFFAF9F5);
Color ink = const Color(0xFF29261F);
Color line = const Color(0xFFE6E3D9);
Color soft = const Color(0xFFF0EEE6);
Color surf = Colors.white;
Color mut = const Color(0xFF6E6B63);
Color mut2 = const Color(0xFF8C897F);
Color btn = const Color(0xFF29261F);
Color onBtn = Colors.white;
Color heroBg = const Color(0xFF29261F);
void Function()? appRefresh;

void applyPalette(bool dark) {
  if (dark) {
    bg = const Color(0xFF191816);
    ink = const Color(0xFFEDEBE4);
    line = const Color(0xFF34312D);
    soft = const Color(0xFF2A2825);
    surf = const Color(0xFF232120);
    mut = const Color(0xFFA7A399);
    mut2 = const Color(0xFF7F7B72);
    btn = const Color(0xFFEDEBE4);
    onBtn = const Color(0xFF191816);
    heroBg = const Color(0xFF2D2A26);
  } else {
    bg = const Color(0xFFFAF9F5);
    ink = const Color(0xFF29261F);
    line = const Color(0xFFE6E3D9);
    soft = const Color(0xFFF0EEE6);
    surf = Colors.white;
    mut = const Color(0xFF6E6B63);
    mut2 = const Color(0xFF8C897F);
    btn = const Color(0xFF29261F);
    onBtn = Colors.white;
    heroBg = const Color(0xFF29261F);
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.load();
  await Store.load();
  runApp(const LumoraApp());
}

class LumoraApp extends StatefulWidget {
  const LumoraApp({super.key});
  @override
  State<LumoraApp> createState() => _LumoraAppState();
}

class _LumoraAppState extends State<LumoraApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    appRefresh = refresh;
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (Prefs.theme == 'system') refresh();
  }

  void _rebuild(Element e) {
    e.markNeedsBuild();
    e.visitChildren(_rebuild);
  }

  void refresh() {
    setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) (context as Element).visitChildren(_rebuild);
    });
  }

  bool get dark =>
      Prefs.theme == 'dark' ||
      (Prefs.theme == 'system' &&
          WidgetsBinding.instance.platformDispatcher.platformBrightness ==
              Brightness.dark);

  @override
  Widget build(BuildContext context) {
    final d = dark;
    applyPalette(d);
    final br = d ? Brightness.dark : Brightness.light;
    return MaterialApp(
      title: 'Lumora',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: br,
        scaffoldBackgroundColor: bg,
        colorScheme:
            ColorScheme.fromSeed(seedColor: accent, brightness: br, surface: bg),
        appBarTheme: AppBarTheme(
            backgroundColor: bg,
            elevation: 0,
            scrolledUnderElevation: 0,
            centerTitle: true,
            foregroundColor: ink,
            surfaceTintColor: Colors.transparent,
            systemOverlayStyle:
                d ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark),
        drawerTheme: DrawerThemeData(backgroundColor: bg),
      ),
      home: const ChatPage(),
    );
  }
}
